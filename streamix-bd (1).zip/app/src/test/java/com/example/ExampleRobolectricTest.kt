package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.StreamixDatabase
import com.example.data.model.User
import com.example.data.repository.SeedData
import com.example.data.repository.StreamixRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var repository: StreamixRepository
    private lateinit var database: StreamixDatabase

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext<Context>()
        database = StreamixDatabase.getInstance(context)
        repository = StreamixRepository(context, database)
    }

    @Test
    fun testAdminProvisioningAndAuthenticationFlow() = runBlocking {
        // 1. Provision a new Admin account
        val createResult = repository.createInitialAdmin(
            username = "ott_master",
            email = "master@streamix.bd",
            password = "SecurePassword#2026",
            fullName = "Master Administrator"
        )
        assertTrue("Admin creation must succeed", createResult.isSuccess)
        val createdAdmin = createResult.getOrNull()
        assertNotNull(createdAdmin)
        assertEquals("ADMIN", createdAdmin?.role)
        assertEquals("ott_master", createdAdmin?.username)

        // 2. Test valid Admin Login with username
        val loginResult = repository.adminLogin("ott_master", "SecurePassword#2026")
        assertTrue("Admin login with username should succeed", loginResult.isSuccess)
        assertEquals("ott_master", repository.currentUser.value?.username)
        assertEquals("ADMIN", repository.currentUser.value?.role)

        // 3. Test valid Admin Login with email
        val emailLoginResult = repository.adminLogin("master@streamix.bd", "SecurePassword#2026")
        assertTrue("Admin login with email should succeed", emailLoginResult.isSuccess)

        // 4. Test invalid Admin Login with wrong password
        val badPassResult = repository.adminLogin("ott_master", "WrongPass123")
        assertFalse("Admin login with invalid password must fail", badPassResult.isSuccess)
        assertEquals("Invalid admin credentials", badPassResult.exceptionOrNull()?.message)

        // 5. Test invalid Admin Login with non-existent username
        val badUserResult = repository.adminLogin("unknown_hacker", "SecurePassword#2026")
        assertFalse("Admin login with unknown user must fail", badUserResult.isSuccess)
        assertEquals("Invalid admin credentials", badUserResult.exceptionOrNull()?.message)

        // 6. Test standard user cannot access Admin Login
        val standardUserResult = repository.signUp("subscriber_john", "john@example.com", "pass123456", "John Doe")
        assertTrue(standardUserResult.isSuccess)
        
        val unauthorizedAdminLogin = repository.adminLogin("subscriber_john", "pass123456")
        assertFalse("Standard user must be rejected from Admin login", unauthorizedAdminLogin.isSuccess)
        assertEquals("Invalid admin credentials", unauthorizedAdminLogin.exceptionOrNull()?.message)
    }

    @Test
    fun testContentItemCrudAndOfflineCache() = runBlocking {
        // Authenticate as Admin
        val adminResult = repository.adminLogin("admin", "Admin#2026")
        assertTrue(adminResult.isSuccess)

        val newContent = com.example.data.model.ContentItem(
            id = "test_movie_01",
            title = "Test Online Movie",
            type = "MOVIE",
            description = "A great synchronized movie",
            genre = "Thriller",
            language = "Bengali",
            releaseYear = 2026,
            durationMinutes = 135,
            rating = 4.9,
            posterUrl = "https://example.com/poster.jpg",
            backdropUrl = "https://example.com/backdrop.jpg",
            videoUrl = "https://example.com/video.mp4"
        )

        // Save content
        repository.saveContent(newContent)

        // Verify it is cached in Room database
        val fetched = repository.getContentById("test_movie_01")
        assertNotNull(fetched)
        assertEquals("Test Online Movie", fetched?.title)

        // Delete content
        repository.deleteContent("test_movie_01")
        val deleted = repository.getContentById("test_movie_01")
        assertNull(deleted)
    }
}
