package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// =========================================================================
// MASTER COLOR SYSTEM — "Midnight Aurora"
// Deep dark cinematic background (#070B18, #0D1326), glassmorphism UI,
// purple + cyan accents, soft pink/purple glow.
// =========================================================================

// Backgrounds
val MidnightBlack = Color(0xFF070B18)
val DarkNavyBg = Color(0xFF0D1326)
val DeepIndigoBg = Color(0xFF141C38)
val SlateDarkBg = Color(0xFF10172E)

// Translucent Glass Surfaces
val GlassSurfaceDark = Color(0xCC0E152E)      // 80% opacity dark navy glass
val GlassSurfaceSubtle = Color(0x66141C38)    // 40% opacity subtle glass
val GlassCardBg = Color(0xB3101833)           // 70% opacity frosted glass
val GlassCardHover = Color(0xCC1A234A)        // Active/Hover glass card
val GlassSurfaceLight = Color(0x1AFFFFFF)     // 10% translucent white highlight
val GlassSurfaceUltraLight = Color(0x0DFFFFFF)// 5% translucent white sheen

// Glass Borders & Outlines
val GlassCardBorder = Color(0x33A855F7)       // Soft violet border (20% opacity)
val GlassCardBorderCyan = Color(0x4000F0FF)   // Soft cyan border (25% opacity)
val GlassCardBorderHover = Color(0x6600F0FF)  // Active cyan border
val GlassWhiteBorder = Color(0x2EFFFFFF)      // Soft translucent white border
val GlassSoftBorder = Color(0x2694A3B8)       // Neutral slate border

// Accents & Neon Highlights
val NeonCyan = Color(0xFF00F0FF)
val CyanAccent = Color(0xFF38BDF8)
val VibrantPurple = Color(0xFFA855F7)
val NeonViolet = Color(0xFF8B5CF6)
val DeepPurple = Color(0xFF6D28D9)
val ElectricMagenta = Color(0xFFE879F9)
val SoftPinkGlow = Color(0xFFF472B6)
val CoralRed = Color(0xFFFF3366)
val EmeraldGreen = Color(0xFF10B981)
val AmberRating = Color(0xFFF59E0B)

// High-Contrast Typography
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// =========================================================================
// Aurora Gradients & Scrims
// =========================================================================
val PurpleCyanGradient = Brush.linearGradient(
    colors = listOf(VibrantPurple, NeonCyan)
)

val AuroraButtonGradient = Brush.horizontalGradient(
    colors = listOf(DeepPurple, VibrantPurple, NeonCyan)
)

val AuroraGlowGradient = Brush.radialGradient(
    colors = listOf(
        VibrantPurple.copy(alpha = 0.35f),
        NeonCyan.copy(alpha = 0.15f),
        Color.Transparent
    )
)

val MidnightAuroraBackground = Brush.verticalGradient(
    colors = listOf(
        DarkNavyBg,
        MidnightBlack,
        Color(0xFF05070F)
    )
)

val HeroScrimGradient = Brush.verticalGradient(
    colors = listOf(
        Color.Transparent,
        Color(0x55070B18),
        Color(0xCC070B18),
        MidnightBlack
    )
)

val PosterScrimGradient = Brush.verticalGradient(
    colors = listOf(
        Color.Transparent,
        Color(0x33070B18),
        Color(0xBB070B18),
        Color(0xF5070B18)
    )
)

val GlassBorderGradient = Brush.linearGradient(
    colors = listOf(
        Color.White.copy(alpha = 0.28f),
        VibrantPurple.copy(alpha = 0.40f),
        NeonCyan.copy(alpha = 0.35f),
        Color.White.copy(alpha = 0.08f)
    )
)

val GlassCardGradient = Brush.linearGradient(
    colors = listOf(
        Color(0xCC131A38),
        Color(0x990E142B)
    )
)


